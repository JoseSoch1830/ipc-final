/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otra;

import javax.swing.ImageIcon;

/**
 *
 * @author jose
 */
public class ImagenResul {
     public ImageIcon iconImage;
public ImageIcon pngDadoR(float DadoR)
 {
if (DadoR==1)
{   
iconImage=new ImageIcon("uno.jpg");
}
else if (DadoR==2)
{   
iconImage=new ImageIcon("dos.jpg");
}
else if (DadoR==3)
{
iconImage=new ImageIcon("tres.jpg");

}  
else if (DadoR==4)
{

iconImage=new ImageIcon("cuatro.png");
}
else if (DadoR==5)
{
iconImage=new ImageIcon("cinco.jpg");
}
else if (DadoR==6)
{
iconImage= new ImageIcon("seis.jpg");

}
    
return iconImage;    
 }
 
 }

    
    
    
