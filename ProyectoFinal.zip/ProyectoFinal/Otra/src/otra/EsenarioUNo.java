/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otra;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JOptionPane;
//import otra.VentanaCrearAutos;

/**
 *
 * @author jose
 */
public class EsenarioUNo extends javax.swing.JFrame {
    private int k;
    private int l;
     private int m;
    private int n;
     private int o;
    private int p;
     private int q;
    private int r;
    private int s=1;
    private int t=2;
//declaracion de atributos 
    int CANTIDAD;
    int COLS=4;
    int FILS=4;
    int i,j;
    JButton[][] CUADRO;
    
    /**
     * Creates new form EsenarioUNo
     */
    public EsenarioUNo() {
        initComponents();
           setMatrix();
           MontañaUbicacion();
           AguaUbicacion();
           VehiculosUbicacion();
       
           
        //centrar ventana
        this.setLocationRelativeTo(null);
    }

    
    
    public void setMatrix() {
       CUADRO = new JButton[FILS][COLS];
        int x = 45;
        int y = 10;
        for ( i = 0; i < FILS; i++) {
            for ( j = 0; j < COLS; j++) {
                //instancia el objeto 
                CUADRO[i][j] = new JButton();
                //color de la matriz de botones 
                CUADRO[i][j].setBackground(java.awt.Color.green);
               
                CUADRO[i][j].setBounds(y, x, 45, 45);
                //se agrego la matriz de botones al panel 
                PanelBotones.add(CUADRO[i][j]);
                //se define un tamaño de panel 
                PanelBotones.setBounds(x * 2, y * 2, x, y);
                //coordenada vertical 
                x += 44;
            }
            
            //coordenada horizontal
            y += 44;
            x = 45;
        }}
        
        
     // for (int i = 0; i < FILS; i++) {
       //    for (int j = 0; j < COLS; j++) {
            
    public class Vehiculoubicacion{
        int s, t;
        public Vehiculoubicacion(int s, int t){
        this.s=s;
        this.t=t;
        
       VerDado ver=new VerDado();
       ver.setVisible(true);
        
        }
    
    
    
    }
    
   
    
      
 public void keyTyped(KeyEvent e) {
    System.out.println(" " +e.getKeyCode());
    }

    public void keyReleased(KeyEvent e) {
     System.out.println("arriba" +e.getKeyCode());
    }
    

    public void keyPressed(KeyEvent e) {
        
        
        if(e.getKeyCode()==38){
           VerDado ver=new VerDado();
           ver.setVisible(true);
            System.out.println("arriba");
            if(this.t!=0){
            this.t-=1;
            t--;
            this.repaint();  
             System.out.println( "poscion " +s+" "+t);
            }
            
        }else if(e.getKeyCode()==40){
            System.out.println("abajo");
            if(this.t!=7){
            this.t+=1;
            t++;
            this.repaint();
             //   System.out.println( "poscion " +posX+" "+posY);
            }
            
        }
        else if(e.getKeyCode()==37){
            System.out.println("izquierda");
            if(this.s!=0){
            this.s+=1;
            s++;
            this.repaint();
             //   System.out.println( "poscion " +posX+" "+posY);
            }
            
        }
        
        else if(e.getKeyCode()==39){
            System.out.println("derecha");
            if(this.s!=0){
            this.s+=1;
            s++;
            this.repaint();
             //   System.out.println( "poscion " +posX+" "+posY);
            }
            
        }  
    }


    
public void MontañaUbicacion(){
    Random aleatorio=new Random();
    k=1+aleatorio.nextInt(1);
    l=1+aleatorio.nextInt(3);
    m=1+aleatorio.nextInt(1);
    n=1+aleatorio.nextInt(3);
CUADRO[k][l].setBackground(Color.red);
CUADRO[m][n].setBackground(Color.red);
}
public void AguaUbicacion(){
    Random aleatorio=new Random();
    o=1+aleatorio.nextInt(3);
    p=1+aleatorio.nextInt(1);
    q=1+aleatorio.nextInt(3);
    r=1+aleatorio.nextInt(1);
 //CUADRO = new JButton[k][l];
CUADRO[o][p].setBackground(Color.blue);
CUADRO[q][r].setBackground(Color.blue);
}

public void VehiculosUbicacion(){
    
     CUADRO[s][t].setBackground(Color.yellow);
     CUADRO[s][t].setText("T");
    
    
}
    
     
 public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaINformacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaINformacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaINformacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaINformacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EsenarioUNo().setVisible(true);
            }
        });
    }
    
    
  
    
    
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelBotones = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout PanelBotonesLayout = new javax.swing.GroupLayout(PanelBotones);
        PanelBotones.setLayout(PanelBotonesLayout);
        PanelBotonesLayout.setHorizontalGroup(
            PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 353, Short.MAX_VALUE)
        );
        PanelBotonesLayout.setVerticalGroup(
            PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 502, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(253, 187, 120));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("ATACAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(72, 110, -1, -1));

        jButton2.setText("MOVER");
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        VerDado ver=new VerDado();
        ver.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelBotones;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}


