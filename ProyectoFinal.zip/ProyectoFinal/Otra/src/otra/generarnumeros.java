/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otra;

import java.util.Random;

/**
 *
 * @author jose
 */
public class generarnumeros {
        public int iValorTirada;

public int calcularnumero()
{

 Random rGenerador = new Random();  
 
iValorTirada = rGenerador.nextInt(6)+1; 

return iValorTirada;
}
    
}
