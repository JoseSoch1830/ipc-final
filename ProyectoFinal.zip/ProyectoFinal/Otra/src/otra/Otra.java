/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otra;

/**
 *
 * @author jose
 */
public class Otra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ventana1 ve=new Ventana1();
        ve.setVisible(true);
        ve.setLocationRelativeTo(null);
    }
    
}
